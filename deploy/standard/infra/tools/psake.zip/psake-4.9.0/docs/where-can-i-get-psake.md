The source code has moved to GitHub: 
 * https://github.com/psake/psake.git
 * git://github.com/psake/psake.git

You can also download ZIP files of the project "binaries" from GitHub by selecting the appropriate [release](https://github.com/psake/psake/releases).
