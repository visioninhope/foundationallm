task A {}
task B {}
task A {}