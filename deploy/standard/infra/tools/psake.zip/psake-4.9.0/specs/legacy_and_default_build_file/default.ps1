task default -depends alegacydefaulttask

task alegacydefaulttask {
    "This is the default build file"
}