The following is a list (at the time of writing) of projects who are using psake to orchestrate their build process.

* [ChocolateyGUI](https://github.com/chocolatey/ChocolateyGUI)
* [BoxStarter](https://github.com/mwrock/boxstarter)
* [ravendb](https://github.com/ravendb/ravendb)
* [Hangfire](https://github.com/HangfireIO/Hangfire)
* [Json.Net](https://github.com/JamesNK/Newtonsoft.Json)
