task default
task A -alias a {}
task B -alias b {}
task C -alias a {}