$config.modules = @("ModuleA.psm1", "ModuleB.psm1")
$config.moduleScope = "global"