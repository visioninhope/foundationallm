task default -depends defaultbuildfile

task adefaulttask {
    "This is the default build file"
}