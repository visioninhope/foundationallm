task default -depends twbdn

task Task_With_Big_Descriptve_Name -alias twbdn {
    "Doing stuff inside task with alias"
}
