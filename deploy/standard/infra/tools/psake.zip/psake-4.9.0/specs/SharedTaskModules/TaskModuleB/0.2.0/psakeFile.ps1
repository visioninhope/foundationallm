
task TaskAFromModuleB {
    'Executing [TaskA] from module [TaskModuleB] version [0.2.0]'
}

task TaskBFromModuleB {
    'Executing [TaskB] from module [TaskModuleB] version [0.2.0]'
}
