function Execute-ModuleAFunction {
    Execute-ModuleBFunction
}

Export-ModuleMember -Function "Execute-ModuleAFunction"
